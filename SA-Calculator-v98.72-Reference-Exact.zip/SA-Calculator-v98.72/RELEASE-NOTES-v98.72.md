# SA Calculator v98.72 — Reference geometry and keypad behavior

- Re-measured the supplied 709×1536 screenshots and 720×1560 Loan Calculator recording.
- Matched logical card dimensions, field icon tile sizes, gaps, corner radii, typography, coral active controls, and light reference surface colors.
- Matched the visible Unit Converter category strip and changed its tall keypad action to a From/To swap control.
- Changed Calculate/equals to dismiss the shared keypad after calculating; tapping an input reopens it. Loan tenure picker remains modal above the active keypad, matching the recording.
- Kept age/date input on the native date picker path with no numeric keypad auto-open.
- Preserved dark theme with separate dark surface tokens.
- Release identity: `1.98.86-v98.72`, Android versionCode `1098300`, service-worker cache `v9872`.

## Verification boundary
Automated source tests and fresh web-bundle checks are run locally. APK build and real-device visual/touch verification must be completed by GitHub Actions and on-device installation.
- Detailed source-derived dimensions and per-screen behavior inventory: `VIDEO-SCREENSHOT-MICRO-AUDIT-v98.72.md`.
