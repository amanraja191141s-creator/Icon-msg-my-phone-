# Screenshot + video micro-level audit — SA Calculator v98.72

## Source evidence reviewed
- Eight user screenshots at 709×1536 px: GST, Loan, Saving, Tip, Percentage, Age, Unit and BMI screens.
- User screen recording `Screenrecording_20261123_093855.mp4`, 720×1560 px, 34 seconds; 34 sampled frames reviewed, including Loan entry, validation, tenure modal, result and re-edit states.

## Measured reference geometry (approximate logical dimensions)
The captures are high-density Android screenshots. The following measurements are the visible pixel bounds converted to practical responsive CSS dimensions; they are reference targets, not a claim of exact device-rendered pixel equivalence.

| Element | Screenshot bounds / observed size | Implementation target |
|---|---:|---:|
| Main form card width | x≈24–685 px (≈93% width) | 12 px side inset, full available width |
| Standard form card height | ≈177–180 physical px | 88–90 logical px minimum |
| Standard vertical card gap | ≈20–22 physical px | 10–12 logical px |
| Icon tile | ≈100×100 physical px | 50×50 logical px |
| Card border | ≈3–4 physical px | 2 logical px |
| Field label | ≈29–31 physical px text height | 15 logical px font |
| Field value / placeholder | ≈42–46 physical px | 22–23 logical px font |
| Unit / BMI switch | ≈55 physical px high | 28–30 logical px control height |
| Age Calculate button | ≈525×91 physical px | ≈77% width, 46 logical px min-height |
| Shared keypad | 4 columns × 4 rows; last key spans rows 3–4 | 4×4 CSS grid, equal key spans 2 rows |
| Loan tenure dialog | ≈684×661 physical px | ≈340×330 logical px max dialog |

## Screen-specific findings and changes

### BMI
- Two separate white cards, each with a coral scale icon tile.
- Weight unit switch is right-aligned below the first card; height switch below the second.
- `kg` and `cm` selected states are coral; alternatives are light grey.
- Numeric keypad appears when the tool opens / an editable field is focused; result remains hidden until a valid calculation is requested.
- Existing legacy age/gender/BMR controls are not shown in the reference surface.

### Age
- Date of Birth card and Today card are separate, stacked cards.
- Date placeholder is `DD-MM-YYYY`; native date picker remains the actual input interaction.
- Today is formatted `DD-MM-YYYY` dynamically, not hardcoded.
- Calculate is a wide coral pill. Numeric keypad does not auto-open for this screen.
- Result card remains hidden until a DOB is submitted.

### Unit Converter
- Horizontal category-chip strip remains visible above the conversion cards.
- Initial Weight state uses Kilogram → Gram and value 1 → 1000.
- Unit full names are shown as card headings; abbreviated unit codes remain at the right edge.
- Tall coral keypad key is a vertical swap action (⇅), not equals. Swapping preserves the keypad and updates the conversion direction.

### Percentage
- Original Amount first; Percentage second.
- Two horizontal icon cards, amount placeholder and rate placeholder.
- Shared numeric keypad remains while editing; equals calculates and dismisses the keypad.

### Saving
- Reference surface displays Saving Amount, Interest Rate(%) and Saving Period in three stacked cards.
- Advanced monthly contribution / frequency / tax controls remain available to calculation state but are not exposed in this reference layout.
- Equals calculates, reveals the result, and dismisses the keypad.

### GST
- Original Amount card, right-aligned With GST / Without GST segmented controls, GST Rate card with 5% / 18% quick choices, and Same State / Different State controls.
- GST amount and split results are not shown before Calculate.
- Equals calculates and reveals results; editing an input resets the result visibility.

### Loan
- Three stacked horizontal icon cards: Loan Amount, Interest Rate(%) and Loan Tenure.
- Tenure stored as a single month count; picker has independent Years and Months wheels, selected row highlight, Cancel and Done.
- Picker opens over the screen and leaves the existing keypad state beneath it as shown in the recording.
- Equals calculates four result rows and closes the keypad. Tapping an input again hides stale results and reopens the keypad.

### Tip
- Three horizontal cards: Bill Amount, Tip Rate(%) and Number of Person.
- Four result rows are hidden until calculation; keypad is visible during entry and dismissed after equals.

## Cross-screen behavior
- Back navigation closes the keypad before leaving a tool.
- Numeric keypad uses the same 4-column layout and action-key placement across tools.
- `AC`, delete and numeric entry retain the shared field target.
- Unit swap is the intentional exception to Calculate: it swaps units without dismissing the keypad.
- Age date selection uses the native date picker and does not invoke the numeric keypad.
- Light reference theme uses #F4F5F7 background, white cards, #E3E4E6 borders, #FE6F61 coral and #FFE5E4 icon tiles. Dark mode receives separate dark surfaces.

## Verification boundary
- 45/45 automated source regression tests pass.
- JavaScript syntax, web bundle synchronization, CSS/asset references and ZIP integrity are checked.
- No Android APK build or physical-device screenshot comparison is claimed in this local environment. GitHub Actions and installation on the user's device remain required for final device-level certification.
