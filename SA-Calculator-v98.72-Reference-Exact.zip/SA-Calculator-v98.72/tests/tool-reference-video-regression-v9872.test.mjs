import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve('.');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const js=fs.readFileSync(path.join(root,'assets/js/app.js'),'utf8');
const css=fs.readFileSync(path.join(root,'assets/css/tool-reference-ui.css'),'utf8');
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
test('reference geometry tokens cover all eight supplied screenshot tools',()=>{
 for(const token of ['--sa-ref-accent:#fe6f61','min-height:88px','width:50px','height:50px','border-radius:22px','screen-bodymetrics','screen-agecalc','screen-salestax','screen-percent','screen-savings','screen-units','screen-loan','screen-tip']) assert.ok(css.includes(token),`missing ${token}`);
});
test('tool keypad equals dismisses after calculate and unit mode swaps instead',()=>{
 assert.match(js,/if \(STATE\.currentScreen === 'units'\)\s*\{\s*document\.getElementById\('btn-unit-swap'\)\?\.click\(\);\s*return;/);
 assert.match(js,/recalculateCurrentScreen\(\);\s*persistPreviousInputs\(\);\s*closeToolKeypad\(\);/);
 assert.match(js,/actionKey\.textContent = isUnitSwap \? '⇅' : '='/);
});
test('reference unit category strip remains visible alongside selected workspace',()=>{
 assert.match(css,/#screen-viewport #screen-units \.unit-category-chooser \{ display:block !important/);
 assert.match(css,/#screen-viewport #screen-units #unit-converter-workspace \{ display:flex !important/);
 assert.match(js,/document\.getElementById\('btn-unit-swap'\)\.onclick/);
});
test('release identity synchronized for v98.72',()=>{
 assert.equal(pkg.version,'1.98.86-v98.72'); assert.equal(pkg.androidVersionCode,1098300);
 assert.match(html,/1\.98\.86-v98\.72/);
 assert.match(fs.readFileSync(path.join(root,'service-worker.js'),'utf8'),/v9872/);
});
test('all required reference screens and source assets exist',()=>{
 for(const id of ['salestax','loan','savings','salary','tip','sip','currencies','discount','percent','units','agecalc','bodymetrics']) assert.ok(html.includes(`id="screen-${id}"`),`${id} screen missing`);
 for(const rel of ['assets/css/tool-reference-ui.css','assets/css/app.css','assets/js/app.js','assets/js/localization.js']) assert.ok(fs.existsSync(path.join(root,rel)));
});
